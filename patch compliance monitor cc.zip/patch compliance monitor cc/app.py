
from flask import Flask, render_template, jsonify, request
import sqlite3
import os

app = Flask(__name__)
# Database configuration
DATABASE = os.path.join(
    os.path.dirname(__file__),
    "database",
    "patch_monitor.db"
)


# ======================================
# DATABASE CONNECTION
# ======================================

def get_db_connection():

    os.makedirs(os.path.dirname(DATABASE), exist_ok=True)

    connection = sqlite3.connect(DATABASE)

    connection.row_factory = sqlite3.Row

    return connection


# ======================================
# CREATE DATABASE TABLE
# ======================================

def create_database():

    connection = get_db_connection()

    connection.execute("""
        CREATE TABLE IF NOT EXISTS computers (

            id INTEGER PRIMARY KEY AUTOINCREMENT,

            computer_name TEXT NOT NULL UNIQUE,

            installed_count INTEGER DEFAULT 0,

            missing_count INTEGER DEFAULT 0,

            failed_count INTEGER DEFAULT 0,

            status TEXT DEFAULT 'Unknown'

        )
    """)

    connection.commit()

    # Insert sample records if database is empty
    count = connection.execute(
        "SELECT COUNT(*) FROM computers"
    ).fetchone()[0]

    if count == 0:

        sample_data = [
            ("Computer-01", 25, 0, 0, "Compliant"),
            ("Computer-02", 18, 3, 0, "Non-Compliant"),
            ("Computer-03", 20, 0, 0, "Compliant"),
            ("Computer-04", 0, 0, 0, "Pending"),
            ("Computer-05", 0, 0, 0, "Unknown")
        ]

        connection.executemany("""
            INSERT INTO computers (
                computer_name,
                installed_count,
                missing_count,
                failed_count,
                status
            )
            VALUES (?, ?, ?, ?, ?)
        """, sample_data)

        connection.commit()

    connection.close()


# ======================================
# HOME PAGE
# ======================================

@app.route("/")
def home():

    return render_template("index.html")


# ======================================
# BACKEND HEALTH CHECK
# ======================================

@app.route("/api/health")
def health():

    return jsonify({
        "status": "success",
        "message": "Backend is running successfully",
        "application": "Patch Compliance Monitoring System"
    })


# ======================================
# GET ALL COMPUTERS
# ======================================

@app.route("/api/computers", methods=["GET"])
def get_computers():

    connection = get_db_connection()

    records = connection.execute(
        "SELECT * FROM computers ORDER BY id"
    ).fetchall()

    connection.close()

    return jsonify([
        dict(record) for record in records
    ])


# ======================================
# GET DASHBOARD SUMMARY
# ======================================

@app.route("/api/summary", methods=["GET"])
def get_summary():

    connection = get_db_connection()

    result = connection.execute("""
        SELECT
            COUNT(*) AS total,

            SUM(CASE
                WHEN status = 'Compliant'
                THEN 1 ELSE 0 END
            ) AS compliant,

            SUM(CASE
                WHEN status = 'Pending'
                THEN 1 ELSE 0 END
            ) AS pending,

            SUM(CASE
                WHEN status = 'Non-Compliant'
                THEN 1 ELSE 0 END
            ) AS noncompliant

        FROM computers
    """).fetchone()

    connection.close()

    return jsonify({
        "total": result["total"] or 0,
        "compliant": result["compliant"] or 0,
        "pending": result["pending"] or 0,
        "noncompliant": result["noncompliant"] or 0
    })


# ======================================
# ADD COMPUTER
# ======================================

@app.route("/api/computers", methods=["POST"])
def add_computer():

    data = request.get_json(silent=True) or {}

    name = data.get("computer_name")

    if not isinstance(name, str) or not name.strip():
        return jsonify({
            "error": "Computer name is required"
        }), 400

    connection = get_db_connection()

    try:

        connection.execute("""
            INSERT INTO computers (
                computer_name,
                installed_count,
                missing_count,
                failed_count,
                status
            )
            VALUES (?, 0, 0, 0, 'Unknown')
        """, (name.strip(),))

        connection.commit()

        return jsonify({
            "message": "Computer added successfully"
        }), 201

    except sqlite3.IntegrityError:

        return jsonify({
            "error": "Computer already exists"
        }), 409

    finally:

        connection.close()


# ======================================
# DELETE COMPUTER
# ======================================

@app.route("/api/computers/<int:computer_id>", methods=["DELETE"])
def delete_computer(computer_id):

    connection = get_db_connection()

    cursor = connection.execute(
        "DELETE FROM computers WHERE id = ?",
        (computer_id,)
    )

    connection.commit()

    connection.close()

    if cursor.rowcount == 0:

        return jsonify({
            "error": "Computer not found"
        }), 404

    return jsonify({
        "message": "Computer deleted successfully"
    })


# ======================================
# START APPLICATION
# ======================================

create_database()

if __name__ == "__main__":

    app.run(
        host="127.0.0.1",
        port=5000,
        debug=True
    )
